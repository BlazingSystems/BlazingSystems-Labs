# Blaze Ultimate Optimizer — Low-Spec Windows Edition v1.0 Preview

**A genuinely native 64-bit Windows desktop `.exe`** made for unusually constrained Windows 11/10 PCs. No installer, .NET runtime, PowerShell, Java, always-running service, network account, telemetry, or external bundled DLL is needed. The app is deliberately small and does not run until you launch it.

## What you can do

- **1-CLICK DIAGNOSE** — read-only snapshot of physical memory pressure, Windows commit capacity, OS disk free space, short CPU/process CPU sample, leading process working sets, common Registry Run entries, and classic Windows System/Application event records from up to 7 days (subject to record cap and access).
- **DIAGNOSE + SAFE FIX** — requires a yes/no confirmation; backs up the user's original Windows UI effects and transparency preferences, switches the effects off, and removes only files in `%LOCALAPPDATA%\Temp\` that are **over 7 days old**, in the *top directory only*. Ignores directories, directory junctions, reparse-point files, and locked/recent files. Automatically rechecks and reports before/after disk space and memory usage.
- **OLD TEMP CLEANUP** — conservative cleanup as described above (it does not touch the Windows directory, browser caches, user Documents, Downloads, desktop or other drives).
- **RESTORE PREFERENCES** — restores the saved animation/transparency settings. Deleted temp files cannot be recovered.
- **OPEN REPORT FILE** — opens the local UTF-16 text report, saved under `%LOCALAPPDATA%\BlazeUltimateOptimizer-Report.txt`.
- **STARTUP APPS** — opens Windows Settings to let you review and select startup apps yourself.

The report categorizes likely bottlenecks and possible disk/controller, WHEA, unexpected power-off, app crash and app hang *indicators*. Event IDs are correlated with provider names where applicable, but **a log event is a diagnostic clue, not proof of root cause**. Some modern event channels and startup sources are not scanned.

## How to use

1. Copy **BlazeUltimateOptimizer.exe** to the affected PC. Run it normally: administrator privileges are **not** required for normal checks and safe UI changes.
2. Click **1-CLICK DIAGNOSE**. Read the **FINAL VERDICT** section in the output.
3. If desired, click **DIAGNOSE + SAFE FIX**, review and confirm the changes. Check the automatically refreshed verdict and action receipt.
4. Use **RESTORE PREFERENCES** if you want the original appearance settings back.
5. Open the report to save/share text for deeper analysis. Be careful sharing it; it can contain process names and Windows installation details.

### Important safety and limitations

- Never forcibly disables Windows Update, Defender, essential services, paging/pagefile, restore functionality, or security features.
- Never edits system drivers, BIOS, Windows system files, or runs aggressive registry cleaning/SSD defragmentation.
- Cleaning old temporary files is irreversible. It intentionally does not empty the Recycle Bin or delete nested temp folders.
- The one-click actions cannot solve a physically faulty SSD, corruption requiring admin-assisted SFC/DISM/CHKDSK, malware, sustained thermal throttling, unsupported Windows 11 hardware, or permanently insufficient capacity. The report recommends low-cost *diagnostic steps* for such cases instead of suggesting RAM upgrades.
- A CPU utilization sample lasting approximately 430 ms is a snapshot; repeat with the same workload if necessary.
- Windows 11 formally requires **at least 4 GB RAM and a 64 GB storage device**, so a 32 GB installation is outside the published minimum. Expect hard limits even after tuning.
- App binary is **unsigned** and may be flagged by Windows SmartScreen (do not override a security warning unless you trust the binary and understand the risk).
- **Cross-compiled and PE/import-table verified on Linux; not yet executed or validated on a Windows 11 machine.** This is a **preview**, not a certified repair suite.

## Building from source

`BlazeUltimateOptimizer.c` is self-contained C, using documented native Windows APIs. `build.py` demonstrates a cross-compile using Clang for `x86_64-windows-msvc` and `lld-link` with import libraries synthesized from `.def` files. It requires Clang and LLVM's `lld-link` on PATH. No generated `.dll` files ship with the EXE: it imports standard Windows system DLLs only.

Cross-compile: `python build.py`.

## Project design

The app does not run continuously; it is a targeted diagnostic and user-authorized maintenance assistant. It was designed for strict storage/RAM constraints rather than dramatic but misleading "RAM cleaning" claims. No performance gain is guaranteed.
