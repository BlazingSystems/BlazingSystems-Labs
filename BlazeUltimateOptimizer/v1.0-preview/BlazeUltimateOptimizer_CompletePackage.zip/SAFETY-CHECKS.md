# Static verification checklist

- [x] Built PE32+ x86-64 Windows GUI executable with Clang + lld-link
- [x] Checked binary uses only kernel32.dll, user32.dll, gdi32.dll, advapi32.dll, shell32.dll
- [x] Confirmed read-only scan has no file-delete or registry-write actions
- [x] Confirmed auto-fix requires a user confirmation dialog
- [x] Confirmed temp cleanup targets only LOCALAPPDATA\\Temp top-level old files and avoids reparse points
- [x] Confirmed visual settings are backed up in per-user registry and can be restored
- [x] Confirmed app does not terminate processes or disable essential services
- [x] Confirmed report states uncertainty around event IDs and excludes unperformed checks
- [ ] Run the app on a real Windows 11 PC and verify UI, registry round trip, storage/event-log access, cleanup, and report persistence
- [ ] Verify behavior on an actual ~1 GB RAM machine and 32 GB Windows boot SSD
- [ ] Code-sign any redistributed production build

Build checks are not a substitute for runtime Windows testing.
