import re, pathlib, subprocess
p=pathlib.Path(__file__).parent
s=(p/'BlazeUltimateOptimizer.c').read_text()
all_functions=re.findall(r'^DLL\s+[^\n]+?\s+WINAPI\s+(\w+)\s*\(',s,re.M)
libs={"kernel32":[],"user32":[],"gdi32":[],"advapi32":[],"shell32":[]}
user=set('MessageBoxW PostMessageW SendMessageW DefWindowProcW LoadCursorW RegisterClassExW CreateWindowExW ShowWindow UpdateWindow SetWindowTextW MoveWindow EnableWindow DestroyWindow PostQuitMessage GetMessageW TranslateMessage DispatchMessageW SystemParametersInfoW'.split())
gdi={'GetStockObject'}
adv=set('RegOpenKeyExW RegCreateKeyExW RegQueryValueExW RegSetValueExW RegDeleteValueW RegEnumValueW RegCloseKey OpenEventLogW ReadEventLogW CloseEventLog'.split())
shell={'ShellExecuteW'}
for a in all_functions:
    x='user32' if a in user else 'gdi32' if a in gdi else 'advapi32' if a in adv else 'shell32' if a in shell else 'kernel32'
    libs[x].append(a)
for lib,names in libs.items():
    (p/(lib+'.def')).write_text('LIBRARY '+lib+'.dll\nEXPORTS\n'+''.join(' '+name+'\n' for name in sorted(set(names))))
    subprocess.run(['lld-link','/dll','/noentry','/def:'+str(p/(lib+'.def')),'/out:'+str(p/(lib+'.dll')),'/implib:'+str(p/(lib+'.lib'))],check=True,stdout=subprocess.PIPE)
subprocess.run(['clang','--target=x86_64-windows-msvc','-ffreestanding','-fno-stack-protector','-fno-builtin','-O2','-Wall','-Wextra','-Wno-unused-function','-c',str(p/'BlazeUltimateOptimizer.c'),'-o',str(p/'BlazeUltimateOptimizer.obj')],check=True)
subprocess.run(['lld-link','/subsystem:windows','/entry:mainCRTStartup','/machine:x64','/opt:ref','/opt:icf','/out:'+str(p/'BlazeUltimateOptimizer.exe'),str(p/'BlazeUltimateOptimizer.obj')]+[str(p/(l+'.lib')) for l in libs],check=True)
print('Built',p/'BlazeUltimateOptimizer.exe')
