from pathlib import Path
import sys
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
src=p/'BlazeUltimateOptimizer.c'
s=src.read_text(encoding='utf-8')
def change(old,new,label):
    global s
    if old not in s: raise RuntimeError('expected source missing: '+label)
    s=s.replace(old,new,1)

change('typedef struct {WCHAR name[120]; WCHAR module[120]; unsigned count;} FAULT;',
'''typedef struct {WCHAR name[120]; WCHAR module[120]; WCHAR exception[32]; WCHAR appPath[260]; unsigned count; DWORD newest;} FAULT;''','fault struct')
change('static int g_app_names_count=0;', 'static int g_app_names_count=0;\nstatic ULONGLONG g_current_event_epoch=0;','event epoch')
a=s.index('static void store_crash(')
b=s.index('static void process_snapshot(',a)
s=s[:a]+'''static void store_crash(LPCWSTR app,LPCWSTR mod,LPCWSTR exception,LPCWSTR path,DWORD eventEpoch){
    if(!app||!app[0])app=L"(name not available)";
    if(!mod)mod=L"";if(!exception)exception=L"";
    int k=0;
    for(;k<g_app_names_count;k++)if(same_ci(g_faults[k].name,app)&&same_ci(g_faults[k].module,mod)&&same_ci(g_faults[k].exception,exception))break;
    if(k>=12)return;
    if(k==g_app_names_count){
        g_app_names_count++;
        wcopy(g_faults[k].name,app,120);wcopy(g_faults[k].module,mod,120);
        wcopy(g_faults[k].exception,exception,32);wcopy(g_faults[k].appPath,path?path:L"",260);
        g_faults[k].count=0;g_faults[k].newest=0;
    }
    g_faults[k].count++;
    if(eventEpoch>g_faults[k].newest)g_faults[k].newest=eventEpoch;
}
static void crash_insertions(const EVENTLOGRECORD*r){
    /* Application Error event 1000 insertion order is commonly:
       1 app; 4 module; 7 exception code; 11 application path.
       Read only NUL-terminated UTF-16 strings within the original record. */
    if(r->NumStrings<1||r->StringOffset>=r->Length||r->StringOffset<sizeof(EVENTLOGRECORD)||(r->StringOffset&1))return;
    DWORD byteOff=r->StringOffset;
    WCHAR app[120],mod[120],exception[32],path[260];
    app[0]=mod[0]=exception[0]=path[0]=0;
    for(unsigned k=0;k<r->NumStrings&&k<11;k++){
        WCHAR tmp[260];UINT j=0;int terminated=0;
        while(byteOff+2<=r->Length){
            WCHAR wc=*(const WCHAR*)((const BYTE*)r+byteOff);byteOff+=2;
            if(!wc){terminated=1;break;}
            if(j+1<260)tmp[j++]=wc;
        }
        if(!terminated)return;
        tmp[j]=0;
        if(k==0)wcopy(app,tmp,120);
        if(k==3)wcopy(mod,tmp,120);
        if(k==6)wcopy(exception,tmp,32);
        if(k==10)wcopy(path,tmp,260);
    }
    store_crash(app,mod,exception,path,r->TimeGenerated);
}
''' + s[b:]
change('WCHAR*provider=(WCHAR*)((BYTE*)r+sizeof(EVENTLOGRECORD));if(r->EventType',
'''WCHAR provider[120];UINT pn=0;DWORD po=sizeof(EVENTLOGRECORD);int foundEnd=0;
while(po+2<=r->Length){WCHAR wc=*(const WCHAR*)((const BYTE*)r+po);po+=2;if(!wc){foundEnd=1;break;}if(pn+1<120)provider[pn++]=wc;}
provider[pn]=0;
if(!foundEnd){off+=r->Length;continue;}
if(r->EventType''','bounded provider')
change('ULONGLONG cur=ft64(ft)/10000000ULL-11644473600ULL;DWORD limit=',
       'ULONGLONG cur=ft64(ft)/10000000ULL-11644473600ULL;g_current_event_epoch=cur;DWORD limit=', 'event time')
change('heading(L"APPLICATION CRASH SUSPECTS - EVENT 1000 INSERTIONS");',
       'heading(L"APPLICATION CRASH CLUSTERS - EVENT 1000 DETAILS");', 'report crash heading')
old='''for(int i=0;i<g_app_names_count;i++){append(L"  ");append(g_faults[i].name);append(L" - ");num(g_faults[i].count);append(L" event(s)");if(g_faults[i].module[0]){append(L" | faulting module candidate: ");append(g_faults[i].module);}nl();}
line(L"Candidate strings only. Verify full provider message / dump before attributing root cause.");
make_recommendations();}'''
new='''for(int i=0;i<g_app_names_count;i++)for(int j=i+1;j<g_app_names_count;j++)if(g_faults[j].count>g_faults[i].count){FAULT tmp=g_faults[i];g_faults[i]=g_faults[j];g_faults[j]=tmp;}
for(int i=0;i<g_app_names_count;i++){
    append(L"  ");append(g_faults[i].name);append(L" - ");num(g_faults[i].count);append(L" crash record(s)");
    if(g_faults[i].module[0]){append(L" | module: ");append(g_faults[i].module);}
    if(g_faults[i].exception[0]){append(L" | exception: ");append(g_faults[i].exception);}
    if(g_faults[i].newest&&g_current_event_epoch>=g_faults[i].newest){append(L" | latest approximately ");num((g_current_event_epoch-g_faults[i].newest)/3600ULL);append(L"h ago");}
    nl();
    if(g_faults[i].appPath[0]){append(L"    app path: ");append(g_faults[i].appPath);nl();}
}
line(L"Event 1000 inserted fields are evidence, not proof that the named module caused the fault. Records may repeat or be truncated.");
heading(L"TARGETED FAULT TRIAGE - NO AUTOMATIC DRIVER CHANGES");
int matched=0;
for(int i=0;i<g_app_names_count;i++){
  if(same_ci(g_faults[i].name,L"AUDIODG.EXE")&&contains_ci(g_faults[i].module,L"CX64")){
    line(L"AUDIO: Windows audio engine crashes with a Conexant-family CX64 module. Test disabling Audio Enhancements on the output device, then check your device maker's matching driver. Do not terminate audiodg.exe or disable audio services.");matched=1;
  }else if(contains_ci(g_faults[i].name,L"E_YAR")||contains_ci(g_faults[i].module,L"E_YAP")){
    line(L"EPSON-RELATED: Possible Epson printer status-monitor component. If printing works but the monitor crashes, repair that matching Epson utility; do not disable the Windows Print Spooler blindly.");matched=1;
  }else if(same_ci(g_faults[i].module,L"KERNELBASE.dll")){
    line(L"GENERIC WINDOWS MODULE: KERNELBASE.dll identifies where an exception surfaced, not necessarily the cause. Use the app path and exception code to investigate this specific program.");matched=1;
  }
}
if(!matched)line(L"No safe vendor-specific repair pattern matched. Inspect full Event Viewer messages before changing drivers or services.");
make_recommendations();}'''
change(old,new,'crash details report')
change('''if(g_highmem){line(L"HIGH LIVE RAM PRESSURE - memory is heavily occupied now.");line(L"ACTION: Close the largest *nonessential* processes in the list; reduce open browser tabs. Do NOT disable the Windows pagefile.");findings++;}''',
'''if(g_highmem){line(L"HIGH LIVE RAM PRESSURE - memory is heavily occupied now.");
line(L"ACTION: End only unused app sessions from their own menus; do not force-close unsaved developer tools, Windows services, or the browser that holds active work. Keep the pagefile SYSTEM-MANAGED.");
if(g_group_count){append(L"Largest private-commit application group: ");append(g_group[0].name);append(L" (multiple processes may be one app session). Private commit is NOT the memory reclaimed by closing it.");nl();}
findings++;}''','memory recommendation')
change('''if(g_crashes||g_hangs){append(L"APPLICATION INSTABILITY - ");num(g_crashes);append(L" crash-ID and ");num(g_hangs);line(L" hang-ID records. Inspect Event Viewer > Windows Logs > Application for failing program and faulting module; reinstall/repair only that program.");findings++;}''',
'''if(g_crashes||g_hangs){append(L"APPLICATION INSTABILITY - ");num(g_crashes);append(L" crash-ID and ");num(g_hangs);line(L" hang-ID records. Consult TARGETED FAULT TRIAGE; SAFE FIX does not repair drivers, applications or these crash records.");findings++;}''','crash recommendation')
change('''line(L"A one-click scan can identify bottlenecks and log evidence but cannot prove every root cause. Metrics are one snapshot. Some event IDs are shared across providers; inspect source/details to confirm. This report does not read SSD SMART health, measure sustained disk I/O, run malware scanning, or verify every Windows file.");''',
'''line(L"Crash clusters are grouped by application, module and exception code. Records and path insertion fields depend on the event provider. Historical crash counts persist after repairs until records age out of the 7-day window.");line(L"A one-click scan cannot prove every root cause. CPU use is one 1.5-second sample. Private commit is NOT total physically occupied RAM. This tool does not measure sustained disk latency, SSD SMART, malware infection, pagefile hard-fault rates, or full component integrity.");''','limitations')
change('''append(L"Memory load: before ");num(beforeMem);append(L"%, after ");num(g_memload);line(L"% (naturally fluctuates; not a RAM boost)");''',
'''append(L"Memory load: before ");num(beforeMem);append(L"%, after ");num(g_memload);line(L"% (naturally fluctuates; not a RAM boost)");
if(g_memload+4<=beforeMem)line(L"OUTCOME: lower observed RAM load, but this snapshot cannot attribute the change to the repair.");
else line(L"OUTCOME: NO MEASURABLE RAM RELIEF from safe fix. Focus on unused application sessions or the specific crash clusters above.");
if(g_crashes)line(L"UNRESOLVED: historical application crashes remain. SAFE FIX does not repair printer/audio drivers or third-party apps.");''','post fix honest outcome')
change('''line(L"BLAZE ULTIMATE OPTIMIZER - Windows 10/11 ultra-low-spec diagnostic v1.1");line(L"Lightweight native x64 / user-mode / offline / zero telemetry");''',
'''line(L"BLAZE ULTIMATE OPTIMIZER - Windows 10/11 ultra-low-spec diagnostic v1.2");line(L"Native Windows x64/ARM64 / user-mode / offline / zero telemetry");''','report version')
change('BLAZE SYSTEMS  |  v1.1.1','BLAZE SYSTEMS  |  v1.2','heading version')
change('Blaze Ultimate Optimizer 1.1.1 Preview','Blaze Ultimate Optimizer 1.2 Preview','window version')
# Make releases correctly identify version in embedded Windows properties.
src.write_text(s,encoding='utf-8')
res=p/'resources.py';q=res.read_text(encoding='utf-8').replace('1.1.1.0','1.2.0.0');res.write_text(q,encoding='utf-8')
ver=p/'verify.py';q=ver.read_text(encoding='utf-8').replace("assert '1.1.1.0'", "assert '1.2.0.0'")
q+='''\nassert 'g_faults[i].exception' in s and 'TARGETED FAULT TRIAGE' in s\nassert 'NO MEASURABLE RAM RELIEF' in s\nassert 'provider[pn]=0' in s\nprint('v1.2 bounded crash parsing and honest safe-fix verdict: PASS (static; Windows test pending)')\n'''
ver.write_text(q,encoding='utf-8')
print('Applied v1.2 diagnostic update')
